package com.example.secretsantadino;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MainActivity2 extends AppCompatActivity {
    TextView textView;
    TextView imeIspis;
    Button btn2;
    ImageView img1;
    ImageView img2;
    ImageView img3;
    TextView txttest;

    Random r;
    ArrayList<String> pokloni;
    ArrayList<String> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        imeIspis = (TextView) findViewById(R.id.textView4);
        r = new Random();
        int dino = r.nextInt(3-0);
        String dino2 = String.valueOf(dino);

        textView =(TextView) findViewById(R.id.textView3);
        img1 = (ImageView) findViewById(R.id.imageView);
        img2 = (ImageView) findViewById(R.id.imageView2);
        img3 = (ImageView) findViewById(R.id.imageView3);
        img1.setVisibility(View.INVISIBLE);
        img2.setVisibility(View.INVISIBLE);
        img3.setVisibility(View.INVISIBLE);
        txttest = (TextView)findViewById(R.id.textView5);

        txttest.setText(dino2);
        Intent noviIntent = getIntent();
        String osoba = noviIntent.getStringExtra("prijelaz");
        list = noviIntent.getStringArrayListExtra("prijelaz2");
        for(int i = 0;i<list.size();i++){
            imeIspis.append(", "+list.get(i).toString());
        }



            if(dino == 0){
                img1.setVisibility(View.VISIBLE);
                textView.setText("cokolada");
            }
            else if(dino == 1){
                img2.setVisibility(View.VISIBLE);
                textView.setText("iphone13");
            }
            else{
                img3.setVisibility(View.VISIBLE);
                textView.setText("Playstation5");
            }





    }
}