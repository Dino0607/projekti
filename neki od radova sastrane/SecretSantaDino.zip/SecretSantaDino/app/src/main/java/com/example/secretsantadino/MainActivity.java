package com.example.secretsantadino;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageButton imgBtn;
    TextView ostali;
    TextView osoba2;
    Random r;
    ArrayList<String> razred;
    Button btn;
    String jednaOsoba;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        imgBtn = (ImageButton) findViewById(R.id.imageButton2);
        razred = new ArrayList<String>();
        razred.addAll(Arrays.asList("Marin Bilić","Marin Boban","Fabio Zetović","Toni Vidović", "Ammar Ibrahimović","Nikola Tomić", "Lovre Džaja", "Duje Klepo", "Luka Grbelja","Roko Bašić","Nikola Marijanović", "Tina Andrić","Dino Vrtlar"));



        imgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(razred.isEmpty()){
                    Toast.makeText(MainActivity.this, "nema više ljudi", Toast.LENGTH_SHORT).show();
                }
                else{
                    r = new Random();
                    Integer odabir = r.nextInt(razred.size());
                    String osobe = razred.get(odabir);
                    razred.remove(osobe);

                    Intent noviIntent = new Intent(MainActivity.this, MainActivity2.class);
                    noviIntent.putExtra("prijelaz",osobe);
                    noviIntent.putExtra("prijelaz2",razred);
                    startActivity(noviIntent);
            }

        }});

    }
}