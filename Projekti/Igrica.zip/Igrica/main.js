
function Player(name,health,damage){
    this.name = name;
    this.health = health;
    this.damage = damage;
}

var ime1 = prompt("unesi ime napadaca");
var health1 = prompt("unesi health napadaca");
var damage1 = prompt("unesi damage napadaca");

var ime2 = prompt("unesi ime defendera");
var health2 = prompt("unesi health drugog igraca");
var damage2 = prompt("unesi damage drugog igraca");

const player1 = new Player(ime1, health1, damage1);
const player2 = new Player(ime2, health2, damage2);
//stvaranje kartice

var card = document.querySelector(".igraci");
var igraci = [player1,player2];
igraci.forEach(igrac => card.innerHTML+=`<div class="card">Player:${igrac.name}<br>health:${igrac.health}<br>damage:${igrac.damage}`);


//ispis konzole

var x = document.querySelector(".game-log");

var attacker = 0;
var defender = 0;

function game(){
        attacker = player1;
        defender = player2;
        defender.health = defender.health - attacker.damage;
        card.innerHTML=`<div class="card">Player:${player1.name}<br>health:${player1.health}<br>damage:${player1.damage}`;
        card.innerHTML+=`<div class="card">Player:${player2.name}<br>health:${player2.health}<br>damage:${player2.damage}`;
        x.append(defender.name + " je primio " + attacker.damage + " damage-a");
        x.append(" stanje health-a defendera " + defender.health)
        if(defender.health<=0){
            x.append(defender.name + " je umro ");
            document.querySelector(".button1").disabled = true;
        }
       

    }


//restart
var buttonRest = document.querySelector(".button2");
function restart(){
    var ime1 = prompt("unesi ime napadaca");
    var health1 = prompt("unesi health prvog igraca");
    var damage1 = prompt("unesi damage prvog igraca");

    var ime2 = prompt("unesi ime defendera");
    var health2 = prompt("unesi health drugog igraca");
    var damage2 = prompt("unesi damage drugog igraca");

    player1.name = ime1;
    player1.health = health1;
    player1.damage = damage1;

    player2.name = ime2;
    player2.health = health2;
    player2.damage = damage2;
    card.innerHTML=`<div class="card">Player:${player1.name}<br>health:${player1.health}<br>damage:${player1.damage}`;
    card.innerHTML+=`<div class="card">Player:${player2.name}<br>health:${player2.health}<br>damage:${player2.damage}`;
    document.querySelector(".button1").disabled = false;
    x.innerHTML="";
}
buttonRest.addEventListener("click", restart);




