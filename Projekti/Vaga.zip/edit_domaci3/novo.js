// supertalent
/* 
let recenica = prompt("Unesite neku recenicu:");
let obrnuta = "";

for(let i = recenica.length -1; i >=0;i--){
    obrnuta += recenica[i];
}
console.log(obrnuta);
*/


//foobar
/* 
let broj = Number(prompt("upiši broj:"));

if(broj%3===0 && broj%5===0){
    console.log("foobar");
}else if(broj%3===0){
    console.log("foo");
}else if(broj%5===0){
    console.log("bar");
}else{
    console.log(broj);
}
*/


//šibice
/* 
let n = Number(prompt("unesi broj kuća:"));
let sibice = 1;

for(let i = n;i>0;i--){
    sibice += 5; 
}
console.log("Za "+n+" kuća, potrebno je "+sibice+" šibica.")
*/


//težina

let tezine = [];
do{
    var unos = prompt("unesi težine ljudi:");
    tezine.push(unos);
}while(unos != 0);

var najmanje = tezine[0];
var najvise = 0;
var index1 = 0;
var index2 = 0;

for(var i = 0; i<tezine.length; i++){
    if(najmanje > parseInt(tezine[i]) && tezine[i] != 0){
        najmanje = tezine[i];
        index1 = i;
    }
    if(najvise < parseInt(tezine[i])){
        najvise = tezine[i];
        index2 = i;
    }
}

if(najvise == najmanje){
    console.log("Svi imaju istu težinu.");
}else{
    console.log("Najteža osoba je "+ ++index2 +"., on/a ima "+najvise+"kg.");
    console.log("Najlakša osoba je "+ ++index1 +"., on/a ima "+najmanje+" kg.");

}

